# Write a program to input 2 number and an arithmetic operator. Display the result accordingly.
a=int(input()); b=int(input()); op=input()
if op=='+': print(a+b)
elif op=='-': print(a-b)
elif op=='*': print(a*b)
elif op=='/': print(a/b)
