# Write a program to input Principal Amount, Rate and Year and display Simple Interest.
p=float(input()); r=float(input()); t=float(input()); print(p*r*t/100)
