# Write a program to input radius of a circle, and print area of that circle.
r=float(input()); print(3.14*r*r)
