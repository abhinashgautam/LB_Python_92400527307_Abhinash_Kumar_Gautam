# List of squares 1 to n
n=int(input()); print([i*i for i in range(1,n+1)])
