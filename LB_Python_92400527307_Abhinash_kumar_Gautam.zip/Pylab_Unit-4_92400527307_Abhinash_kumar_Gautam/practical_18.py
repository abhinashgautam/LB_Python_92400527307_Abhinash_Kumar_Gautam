# Comma-separated numbers list and tuple
nums=input().split(',')
print(nums)
print(tuple(nums))
