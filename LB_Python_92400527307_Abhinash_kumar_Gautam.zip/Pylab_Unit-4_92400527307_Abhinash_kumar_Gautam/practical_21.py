# Read text file line by line
f=open('names.txt','r')
for line in f: print(line.strip())
f.close()
