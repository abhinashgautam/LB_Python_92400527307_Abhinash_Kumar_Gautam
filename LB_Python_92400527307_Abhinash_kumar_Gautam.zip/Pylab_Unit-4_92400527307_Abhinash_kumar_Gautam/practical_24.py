# Class with function overloading style
class Demo:
    def add(self,a,b=0,c=0): return a+b+c
x=Demo(); print(x.add(2,3)); print(x.add(2,3,4))
