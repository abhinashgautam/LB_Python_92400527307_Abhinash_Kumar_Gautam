# Demo for import module in python
import math
print(math.sqrt(25))
