# Bar Plot
import matplotlib.pyplot as plt
x=[1,2,3,4]; y=[10,20,15,25]
plt.bar(x,y,width=0.5)
plt.title('Bar Plot'); plt.show()
