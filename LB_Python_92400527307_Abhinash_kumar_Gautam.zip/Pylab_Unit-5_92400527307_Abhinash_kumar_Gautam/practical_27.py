# Pie Chart
import matplotlib.pyplot as plt
plt.pie([30,20,25,25],labels=['A','B','C','D'],autopct='%1.1f%%')
plt.title('Pie Chart'); plt.show()
