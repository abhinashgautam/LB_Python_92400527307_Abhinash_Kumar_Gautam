# Scatter Plot
import matplotlib.pyplot as plt
x=[1,2,3,4,5,6,7,8]
y=[10,20,15,25,30,18,22,28]
plt.scatter(x,y,s=100,c='blue',edgecolors='black')
plt.title('Scatter Plot'); plt.show()
